package com.mycompany.projetoindividual;

import java.util.Locale;
import java.util.Scanner;

public class ProjetoManga {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        System.out.println("Qual é seu nome?");
        String nome = leitor.next();

        System.out.println(String.format("Oi %s, digite a opção desejada, "
                + "\n 1(para saber quantos capitulos para chegar no atual de"
                + " one piece),"
                + "\n 2(Para dizer se gosta do nosso site ou não), "
                + "\n 3(Informar seu manga favorito),"
                + "\n 4(encerrar)", nome));

        Integer opcaoDigitada = leitor.nextInt();

        if (opcaoDigitada != 1 && opcaoDigitada != 2
                && opcaoDigitada != 3 && opcaoDigitada != 4) {
            System.out.println("Opção invalida, tente novamente");
            opcaoDigitada = leitor.nextInt();
        }
        switch (opcaoDigitada) {
            case 1:

                System.out.println("Em que capitulo de one piece você parou?");
                Integer capituloParou = leitor.nextInt();

                Integer capituloAtual = 1041 - capituloParou;
                System.out.println(String.format("Falta %d capítulos, para chegar no capítulo atual", capituloAtual));
                break;
                
            case 2:
                System.out.println("Você curti nosso site"
                        + " digite s para sim ou n para não?");
                String resposta = leitor.next();
                
                if ("s".equals(resposta)) {
                    System.out.println("Ficamos felizes que esteja gostando");
                } else {
                    System.out.println("Que pena que não teve uma boa "
                            + "experiência");
                }
                break;
            case 3:
                System.out.println("Qual seu manga favorito?");
                String onePiece = leitor.next();

                System.out.println(String.format("%s é realmente incrivel, "
                        + "acompanhe nosso site e verifique se está em nosso "
                        + "catalogo", onePiece));
                break;
            case 4:
                System.out.println(String.format("%s, obrigado por visitar "
                        + "nosso  site, esperamos te ver novamente", nome));
                break;
        }
    }
}
