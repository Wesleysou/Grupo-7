
package com.mycompany.projetoindividual;

import java.lang.invoke.StringConcatException;
import java.util.Scanner;

  
public class ProjetoGustavoLura {
    public static void main(String[] args) {
        Scanner numero = new Scanner(System.in);
        Scanner nome = new Scanner(System.in);
              Boolean retornar = true;
  
      while (retornar) {
          System.out.println("-".repeat(100));
        System.out.println("1-Matemágica\n2-Qual sua empresa?\n3-Adivinhar time"
                + "\n4-Sair\nQual modo você escolhe?:");
        Integer opcaoDigitada = numero.nextInt();
        
        
        while(opcaoDigitada < 1 || opcaoDigitada > 4) {
            System.out.println("Tentativa inválida.Tente novamente: ");
            opcaoDigitada = numero.nextInt();
            }
        
                  
        
        switch(opcaoDigitada){
            case 1:
                System.out.println("-".repeat(100));
                System.out.println("Nome: ");
                String nomeDigitado = nome.nextLine();
                System.out.println("Ano de nascimento: ");
                Integer anoDigitado  = numero.nextInt();
                System.out.println("-".repeat(100));
                
                System.out.println("Seja bem vindo(a)" + nomeDigitado + 
                ", você está no modo 'MATEMÁGICA'.\nVamos fazer uma pequena conta "
                + "que no final mostrará o seu número escolhido\n "
                + "+ sua idade.\nTa duvidando? Então prepare a "
                + "calculadora e vamos nessa! vamos lá.\n\n"
                + "Escolha um número de 1 a 9: ");
                Integer numeroPensado = numero.nextInt();
                
                while (numeroPensado < 1 || numeroPensado > 9) {                    
                System.out.println("Apenas números de 1 a 9, se não a mágica "
                        + "não funciona :( .Tente novamente: ");
                numeroPensado = numero.nextInt();
                }
                
                System.out.println("Após escolher seu número, multiplique ele "
                        + "por dois, e em seguida some 5.\nConseguiu? "
                        + "Digite 1 para sim: ");
                Integer numeroResposta1 = numero.nextInt();
                
                while (numeroResposta1 != 1) {                    
                System.out.println("Tente novamente: ");
                numeroResposta1 = numero.nextInt();
                }
                
                System.out.println("Certo, agora multiplique esse resultado "
                        + "por 50.\nQuando conseguir, tecle 1");
                Integer numeroResposta2 = numero.nextInt();
                
                    while (numeroResposta2 != 1) {                    
                System.out.println("Tente novamente: ");
                numeroResposta2 = numero.nextInt();
                    }
                    
                    System.out.println("Se você ja fez aniversário esse ano?\n"
                    + "Tecle 1 para sim e 2 para não");
                Integer numeroResposta3 = numero.nextInt();
                Integer numeroContaSemIf = (((numeroPensado *2)+5)*50);
                Integer numeroContaComIf = 0;

                        while (numeroResposta3 < 1 || numeroResposta3 > 2) {                            
                System.out.println("Tente novamente: ");
                numeroResposta3 = numero.nextInt();            
                        }

                        if (numeroResposta3 == 1) {
                    numeroContaComIf = (numeroContaSemIf + 1772);
                    System.out.println("Estamos quase terminando...");
                }
                    
                    else if (numeroResposta3 == 2) {
                    numeroContaComIf = (numeroContaSemIf + 1771);
                    System.out.println("Estamos quase terminando...");
                        }
                    
                    System.out.println("Subtraia o resultado dessa operação"
                            + " com o ano do seu nascimento."
                    + "\nQuando conseguir, tecle 1");
                    Integer numeroResposta4 = numero.nextInt();
                    
                    while (numeroResposta4 != 1) {                    
                System.out.println("Tente novamente: ");
                numeroResposta4 = numero.nextInt();
                    }
                    
                    Integer numeroFinal = numeroContaComIf - anoDigitado;
                    System.out.println(String.format("O número final foi "
                            + "%d certo?\nPois bem, o primeiro número da "
                            + "esquerda foi o número que você escolheu, "
                            + "e o restante é sua idade!\nLegal né?", numeroFinal));
                break;
                
            case 2:
        Integer accenture = 0;
        Integer valemobi = 0;
        Integer c6 = 0;
        Integer cip = 0;
        Integer outro = 0;
        String vencedora = "tivemos um empate";
        System.out.println("-".repeat(100));

        System.out.println("Qual empresa tem mais representantes na SPTECH?\n"
                + "Chame mais 5 amigos e vamos fazer a contagem! "
                + "Foram escolhidas algumas empresas\npara a realização da contagem "
                + ", mas não se preocupe, se a sua não estiver, selecione a "
                + "opção 'outro'.\nQual a sua empresa?");
        System.out.println("-".repeat(100));
        for (int i = 0; i < 6; i++) {

        System.out.println("1-Accenture\n2-ValeMobi\n3-C6 Bank\n4-CIP\n5-Outro");
        Integer votoDigitado = numero.nextInt(); 
        
            
            if (votoDigitado == 1) {
                accenture ++;
            }if (votoDigitado == 2) {
                valemobi ++;
            }if (votoDigitado == 3) {
                c6 ++;
            }if (votoDigitado == 4) {
                cip ++;
            }if (votoDigitado == 5) {
                outro ++;
            }
            System.out.println(".".repeat(100));
        }   
        if (accenture > valemobi && accenture > c6 && accenture > cip 
                && accenture > outro) {
            vencedora = "a empresa com mais integrantes é a accenture";
        }
        if (valemobi > accenture && valemobi > c6 && valemobi > cip 
                && valemobi > outro) {
            vencedora = "a empresa com mais integrantes é a valemobi";
        }
        if (c6 > valemobi && c6 > accenture && c6 > cip 
                && c6 > outro) {
            vencedora = "a empresa com mais integrantes é a c6";
        }
        if (cip > valemobi && cip > c6 && cip > accenture 
                && cip > outro) {
            vencedora = "a empresa com mais integrantes é a cip";
        }
        if (outro > valemobi && outro > c6 && outro > cip 
                && outro > accenture) {
            vencedora = "a opção 'outro' tem mais representantes";
        }
        
        System.out.println(String.format("Accenture:%d votos\nValeMobi:%d votos\nS"
                    + "C6 Bank:%d votos\nCIP:%d votos\nOutros:%d votos\n\n"
                + "Ou seja, na sua roda de amigos,%s", accenture,valemobi,c6,
                cip,outro,vencedora));
                                break;

            case 3:
            Integer palmeiras = 0;
            Integer santos = 0;
            Integer corinthians = 0;
            Integer saopaulo = 0;
            String resultado = "0";
                System.out.println("-".repeat(100));
                System.out.println("Pense em um dos 4 grande de São Paulo"
                        + "(Santos,São Paulo,Palmeiras e Corinthians)\ne através"
                        + " de algumas perguntas adivinharemos qual clube\nvocê"
                        + " pensou.Está pronto? Tecle 1 para iniciar");
                            Integer numeroRespostaTime1 = numero.nextInt();

                while (numeroRespostaTime1 != 1) {                            
                System.out.println("Tente novamente: ");
                numeroRespostaTime1 = numero.nextInt();
         
                        }
                System.out.println("Seu time tem mundial?\n1-sim\n2-não");
                Integer numeroRespostaTime2 = numero.nextInt();
                
                while (numeroRespostaTime2 < 1 || numeroRespostaTime2 > 2) {                            
                System.out.println("Tente novamente: ");
                numeroRespostaTime2 = numero.nextInt();            
                        }

                        if (numeroRespostaTime2 == 1) {
                           santos++; 
                           corinthians++; 
                           saopaulo++; 
                }
                    
                    else if (numeroRespostaTime2 == 2) {
                    palmeiras--;
                        }
                        
                        System.out.println("Seu time ja foi rebaixado?\n1-sim\n2-não");
                        Integer numeroRespostaTime3 = numero.nextInt();
                
                while (numeroRespostaTime3 < 1 || numeroRespostaTime3 > 2) {                            
                System.out.println("Tente novamente: ");
                numeroRespostaTime3 = numero.nextInt();            
                        }

                        if (numeroRespostaTime3 == 1) {
                           corinthians++; 
                    palmeiras++;
                }
                    
                    else if (numeroRespostaTime3 == 2) {
                           saopaulo--; 
                           santos--; 
                        }
                        
                    System.out.println("Seu time tem copa do Brasil?\n1-sim\n2-não");
                    Integer numeroRespostaTime4 = numero.nextInt();

                
                while (numeroRespostaTime4 < 1 || numeroRespostaTime4 > 2) {                            
                System.out.println("Tente novamente: ");
                numeroRespostaTime4 = numero.nextInt();            
                        }

                        if (numeroRespostaTime4 == 1) {
                           corinthians++; 
                    palmeiras++;
                           santos++; 
                }
                    
                    else if (numeroRespostaTime4 == 2) {
                           saopaulo--; 
                        }
                
                if (numeroRespostaTime2 == 1 && numeroRespostaTime3 == 1
                    && numeroRespostaTime4 == 1){
                    resultado = "foi o Corinthians";
                }
                else if (numeroRespostaTime2 == 2 && numeroRespostaTime3 == 1
                    && numeroRespostaTime4 == 1){
                    resultado = "foi o Palmeiras";
                }
                else if (numeroRespostaTime2 == 1 && numeroRespostaTime3 == 2
                    && numeroRespostaTime4 == 1){
                    resultado = "foi o Santos";
                }
                else if (numeroRespostaTime2 == 1 && numeroRespostaTime3 == 2
                    && numeroRespostaTime4 == 2){
                    resultado = "foi o São Paulo";
                }else{
                resultado = "NÃO EXISTE";
                }
               
                System.out.println(String.format(" o time pensado %s", resultado));
                                break;

            case 4:
                System.out.println("Espero que tenha gostado! =) ");
            retornar = false;
            }
        }
    }
}
